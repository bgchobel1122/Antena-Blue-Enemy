by FFH4X PRO!
terjemah : 

       Apabila kamu membaca ini, akan ada dua kemungkinan! pertama kamu ingin mencari script dan kedua kamu ingin tau files nya! 
       Sementara itu config ini pertama dibuat oleh #### dan juga belum ada orang lain yang membuat nya, saya sudah mencari di youtube, instagram, facebook, dan media sosial lainnya! apabila ada yang menshare ulang berarti dia menemukan script dan membuatnya! atau mungkin dia hanya mereupload! 
       Jika kamu menemukan orang yang melakukan seperti itu, harap laporkan kepada saya melalui akun sosial media perantara @prygx2 ikuti juga akun nya, agar lebih mudah chat dan merequest-sesuatu config!

saya anda ingin bekerja sama? harap kirimkan pesan ke instagram @prygx2 dengan pesan sebagai berikut : 

hi, i want cooperate with you...
(tulis pesan kamu disini)
thank you

terimakasih!